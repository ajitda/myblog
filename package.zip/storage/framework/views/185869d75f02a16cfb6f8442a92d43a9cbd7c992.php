<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				
			<h2>All posts <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success pull-right">Create</a></h2>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>Id</th>
						<th>Title</th>
						<th>Thumbnail</th>
						<th>Category</th>
						<th>Created at</th>
						<th>Created By</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($post->id); ?></td>
						<td><?php echo e($post->title); ?></td>
						<td><img class="img-responsive" src="<?php echo e(asset($post->image)); ?>" alt="" width="100px"></td>
						<td><?php echo e($post->post_category->name); ?></td>
						<td><?php echo e($post->created_at->toFormattedDateString()); ?></td>
						<td><?php echo e($post->user->name); ?></td>
						<td>
							<a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		
			
			

			</div>		
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>