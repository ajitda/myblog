<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-sm-8 col-sm-offset-2">
			<h2>Edit Post <a href="<?php echo e(url('posts')); ?>" class="btn btn-primary pull-right">Back</a></h2>
			<?php if(count($errors->all()) > 0): ?>
			<div class="alert alert-warning">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<form action="<?php echo e(route('posts.update', $post->id)); ?>" enctype="multipart/form-data" method="POST">
				<?php echo e(csrf_field()); ?>

				<?php echo e(method_field('PUT')); ?>

				<div class="form-group">
					<label for="title">Post Title</label>
					<input type="text" id="title" name="title" value="<?php echo e($post->title); ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="image">Select a post Thumbnail</label>
					<input type="file" id="image" name="image" class="form-control">
				</div>
				<div class="form-group">
					<label for="postcategory">Select A Post Category</label>
					<select name="post_category_id" id="postcategory">Select a Post Category
						<?php $__currentLoopData = $postcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($postcategory->id); ?>" <?php if($post->post_category->id == $postcategory->id): ?> selected <?php endif; ?>><?php echo e($postcategory->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="form-group">
					<label for="description">description</label>
					<textarea name="description" id="description" class="form-control" cols="30" rows="5"><?php echo e($post->description); ?></textarea>
				</div>
				<button type="submit" class="btn btn-primary">Update</button>
			</form>
		</div>
		<div class="col-sm-2" style="margin-top:50px">
			<img src="<?php echo e(asset($post->image)); ?>" alt="" class="img-responsive">
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>