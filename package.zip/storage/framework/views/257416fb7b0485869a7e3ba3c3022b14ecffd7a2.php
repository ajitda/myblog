<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<h1>Profile List <a href="<?php echo e(url('profiles/create')); ?>" class="btn btn-success pull-right">Create</a></h1>
			<?php if(session('status')): ?>
			<div class="alert alert-success">
				<?php echo e(session('status')); ?>

			</div>
			<?php endif; ?>
			<div class="col-sm-12">
				<table id="profile" class="table table-bordered">
					<thead>
						<tr>
							<th>Id</th>
							<th>Name</th>
							<th>Email</th>
							<th>Birth Date</th>
							<th>Image</th>
							<th>Gender</th>
							<th>Address</th>
							<th>Created By</th>
							<th width="180">Action</th>
						</tr>
					</thead>
					<tbody>
						<div style="display: none"><?php echo e($i= 1); ?></div>
						<?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<tr>
							<td><?php echo e($i++); ?></td>
							<td><?php echo e($profile->name); ?></td>
							<td><?php echo e($profile->email); ?></td>
							<td><?php echo e($profile->date_of_birth); ?></td>
							<td><img src="<?php echo e($profile->image); ?>" alt="" class="img-responsive" width="120"></td>
							<td><?php echo e($profile->gender); ?></td>
							<td><?php echo e($profile->address); ?></td>
							<td><?php echo e($profile->user->name); ?></td>
							<td><a href="<?php echo e(route('profiles.show', $profile->id)); ?>" class="btn btn-warning btn-sm">Show</a>
								<a href="<?php echo e(route('profiles.edit', $profile->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

								<a href="#" onclick="return confirm('are you sure')">
								<form class="pull-right" action="<?php echo e(route('profiles.destroy', $profile->id)); ?>" method="POST">
									<?php echo e(csrf_field()); ?>

									<?php echo e(method_field('DELETE')); ?>

									<button class="btn btn-danger btn-sm" type="submit">Delete</button>
									
								</form>

								</a>

							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<!-- <ul class="pagination">
					
				</ul> -->
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	$(document).ready(function() {
	    $('#profile').DataTable();
	} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>