<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				
			<h2>All posts <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success pull-right">Create</a></h2>
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="single-post" style="margin-bottom: 20px">
				<div class="row">
					<div class="col-sm-5">
						<img class="img-responsive" src="<?php echo e(asset($post->image)); ?>" alt="">
					</div>	
					<div class="col-sm-7">
						<h4><?php echo e($post->post_category->name); ?></h4>
						<h3><?php echo e($post->title); ?></h3>
						<p><?php echo e($post->description); ?></p>

						<p><span>Created By : <?php echo e($post->user->name); ?></span> <span class="pull-right">Created at: <?php echo e($post->created_at->toFormattedDateString()); ?></span></p>
					</div>	
					
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>		
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>