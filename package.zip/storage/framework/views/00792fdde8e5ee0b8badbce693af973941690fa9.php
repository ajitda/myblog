<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-sm-7 col-sm-offset-2">
			<h3>Edit Profile</h3>
			<form action="<?php echo e(route('profiles.update', $profile->id)); ?>" enctype="multipart/form-data" method="POST">
				<?php echo e(csrf_field()); ?>

				<?php echo e(method_field('PUT')); ?>

				<div class="form-group">
					<label for="name">Name</label>
					<input type="text" value="<?php echo e($profile->name); ?>" id="name" name="name" class="form-control">
				</div>
				<div class="form-group">
					<label for="email">Email</label>
					<input type="email" id="email" value="<?php echo e($profile->email); ?>" name="email" class="form-control">
				</div>
				<div class="form-group">
					<label for="date_of_birth">Date of Birth</label>
					<input type="date" id="date_of_birth" name="date_of_birth"  value="<?php echo e($profile->date_of_birth); ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="image">Select Your Profile Image</label>
					<input type="file" id="image" name="image" class="form-control">
				</div>
				<div class="form-group">
					<label for="gender">Select Your Gender</label>
					<input type="radio" name="gender" value="male" <?php echo e(($profile->gender == 'male') ? 'checked' : ''); ?>> Male
					<input type="radio" name="gender" value="female" <?php echo e(($profile->gender == 'female') ? 'checked' : ''); ?>> Female
					<input type="radio" name="gender" value="others" <?php echo e(($profile->gender == 'others') ? 'checked' : ''); ?>> Others
				</div>
				<div class="form-group">
					<label for="address">Address</label>
					<textarea name="address" id="address" class="form-control" cols="30" rows="5"><?php echo e($profile->address); ?></textarea>
				</div>
				<button type="submit" class="btn btn-primary">update</button>
			</form>
		</div>
		<div class="col-sm-3">
			<img src="<?php echo e(asset($profile->image)); ?>" class="img-responsive" alt="">
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>