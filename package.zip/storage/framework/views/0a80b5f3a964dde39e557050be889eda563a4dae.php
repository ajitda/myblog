<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
			<?php if(count($errors->all()) > 0): ?>
			<div class="alert alert-warning">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<form action="<?php echo e(route('profiles.store')); ?>" enctype="multipart/form-data" method="POST">
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
					<label for="name">Name</label>
					<input type="text" id="name" name="name" class="form-control">
				</div>
				<div class="form-group">
					<label for="email">Email</label>
					<input type="email" id="email" name="email" class="form-control">
				</div>
				<div class="form-group">
					<label for="date_of_birth">Date of Birth</label>
					<input type="date" id="date_of_birth" name="date_of_birth" class="form-control">
				</div>
				<div class="form-group">
					<label for="image">Select Your Profile Image</label>
					<input type="file" id="image" name="image" class="form-control">
				</div>
				<div class="form-group">
					<label for="gender">Select Your Gender</label>
					<input type="radio" name="gender" value="male"> Male
					<input type="radio" name="gender" value="female"> Female
					<input type="radio" name="gender" value="others"> Others
				</div>
				<div class="form-group">
					<label for="address">Address</label>
					<textarea name="address" id="address" class="form-control" cols="30" rows="5"></textarea>
				</div>
				<button type="submit" class="btn btn-primary">Create</button>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>