<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-sm-8 col-sm-offset-2">
			<h2>Create Post <a href="<?php echo e(url('slides')); ?>" class="btn btn-primary pull-right">Back</a></h2>
			<?php if(count($errors->all()) > 0): ?>
			<div class="alert alert-warning">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<form action="<?php echo e(route('slides.store')); ?>" enctype="multipart/form-data" method="POST">
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
					<label for="title">Slide Title</label>
					<input type="text" id="title" name="title" class="form-control">
				</div>
				<div class="form-group">
					<label for="image">Select a post Thumbnail</label>
					<input type="file" id="image" name="image" class="form-control">
				</div>
				
				<div class="form-group">
					<label for="description">description</label>
					<textarea name="description" id="description" class="form-control" cols="30" rows="5"></textarea>
				</div>
				<button type="submit" class="btn btn-primary">Create</button>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>