<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-sm-offset-3">
				<h1>Profile Details</h1>
				<h3>Name : <?php echo e($profile->name); ?></h3>
				<img src="<?php echo e(asset($profile->image)); ?>" class="img-responsive" alt="">
				<p>Email : <?php echo e($profile->email); ?></p>
				<p>Date Of Birth : <?php echo e($profile->date_of_birth); ?></p>
				<p>Gender : <?php echo e($profile->gender); ?></p>
				<p>Address : <?php echo e($profile->address); ?></p>
				
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>