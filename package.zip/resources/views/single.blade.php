@extends('layouts.app')
@section('content')
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-sm-offset-3">
				<h1>Welcome to Single Page with Blade templating</h1>
			</div>	
		</div>
		
	</div>
@endsection